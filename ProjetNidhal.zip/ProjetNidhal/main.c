#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME_LENGTH 50

typedef struct CompteNode {
    int numero_compte;
    char nom_client[MAX_NAME_LENGTH];
    float solde;
    struct CompteNode* next;
} CompteNode;

void creerCompte(CompteNode** listeComptes) {
    CompteNode* nouveauCompte = (CompteNode*)malloc(sizeof(CompteNode));
    if (nouveauCompte == NULL) {
        printf("Erreur lors de la cr�ation du compte.\n");
        return;
    }

    printf("Entrez le num�ro de compte : ");
    scanf("%d", &nouveauCompte->numero_compte);

    printf("Entrez le nom du client : ");
    while (getchar() != '\n');

    fgets(nouveauCompte->nom_client, sizeof(nouveauCompte->nom_client), stdin);
    nouveauCompte->nom_client[strcspn(nouveauCompte->nom_client, "\n")] = 0;

    printf("Entrez le solde initial : ");
    scanf("%f", &nouveauCompte->solde);

    nouveauCompte->next = *listeComptes;
    *listeComptes = nouveauCompte;
    printf("Compte cr�� avec succ�s.\n");
}


void afficherDetailsCompte(CompteNode* listeComptes, int numCompte) {
    while (listeComptes != NULL) {
        if (listeComptes->numero_compte == numCompte) {
            printf("Num�ro de compte : %d\n", listeComptes->numero_compte);
            printf("Nom du client : %s\n", listeComptes->nom_client);
            printf("Solde : %.3f DT \n ", listeComptes->solde);
            return;
        }
        listeComptes = listeComptes->next;
    }
    printf("Compte non trouv�.\n");
}
void mettreAJourInfosCompte(CompteNode* listeComptes, int numCompte) {
    while (listeComptes != NULL) {
        if (listeComptes->numero_compte == numCompte) {
            printf("Entrez le nouveau nom du client : ");
            scanf("%s", listeComptes->nom_client);
            printf("Entrez le nouveau solde : ");
            scanf("%f", &listeComptes->solde);
            printf("Informations mises � jour avec succ�s.\n");
            return;
        }
        listeComptes = listeComptes->next;
    }
    printf("Compte non trouv�.\n");
}

void supprimerCompte(CompteNode** listeComptes, int numCompte) {
    CompteNode* temp = *listeComptes;
    CompteNode* prev = NULL;

    while (temp != NULL && temp->numero_compte != numCompte) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Compte non trouv�.\n");
        return;
    }

    if (prev == NULL) {
        *listeComptes = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
    printf("Compte supprim� avec succ�s.\n");
}

void afficherListeClients(CompteNode* listeComptes) {
    if (listeComptes == NULL) {
        printf("Aucun client enregistr�.\n");
        return;
    }

    printf("Liste des clients :\n");
    while (listeComptes != NULL) {
        printf("%d. %s\n", listeComptes->numero_compte, listeComptes->nom_client);
        listeComptes = listeComptes->next;
    }
}

void effectuerDepot(CompteNode* listeComptes, int numCompte, float montant) {
    while (listeComptes != NULL) {
        if (listeComptes->numero_compte == numCompte) {
            listeComptes->solde += montant;
            printf("D�p�t de %.3f DT effectu� avec succ�s sur le compte %d.\n", montant, numCompte);
            return;
        }
        listeComptes = listeComptes->next;
    }
    printf("Compte non trouv�.\n");
}

void effectuerRetrait(CompteNode* listeComptes, int numCompte, float montant) {
    while (listeComptes != NULL) {
        if (listeComptes->numero_compte == numCompte) {
            if (listeComptes->solde >= montant) {
                listeComptes->solde -= montant;
                printf("Retrait de %.3f DT effectu� avec succ�s du compte %d.\n", montant, numCompte);
            } else {
                printf("Solde insuffisant pour effectuer le retrait.\n");
            }
            return;
        }
        listeComptes = listeComptes->next;
    }
    printf("Compte non trouv�.\n");
}

void calculerInterets(CompteNode* listeComptes, float tauxInteret,int numcompte) {
    while (listeComptes != NULL) {
        // Supposons que le compte num�ro 0 est un compte d'�pargne
        if (listeComptes->numero_compte ==numcompte) {
            float interets = listeComptes->solde * (tauxInteret / 100);
            listeComptes->solde += interets;
            printf("Int�r�ts de %.3f DT ajout�s au compte �pargne.\n", interets);
            return;
        }
        listeComptes = listeComptes->next;
    }
    printf("Compte d'�pargne non trouv�.\n");
}

int main() {
    CompteNode* listeComptes = NULL;
    int choix;

    FILE* fichier = fopen("comptes.txt", "r");
    if (fichier != NULL) {
        while (!feof(fichier)) {
            CompteNode* nouveauCompte = (CompteNode*)malloc(sizeof(CompteNode));
            if (nouveauCompte == NULL) {
                printf("Erreur lors de la lecture des comptes.\n");
                return 1;
            }

            if (fscanf(fichier, "%d %s %f\n", &nouveauCompte->numero_compte, nouveauCompte->nom_client, &nouveauCompte->solde) == 3) {
                nouveauCompte->next = listeComptes;
                listeComptes = nouveauCompte;
            }
        }
        fclose(fichier);
    }

    do {
        printf("\nBienvenue � Nidhal-E-Bank\n");
        printf("1. Cr�er un nouveau compte\n");
        printf("2. Afficher les d�tails d'un compte\n");
        printf("3. Mettre � jour les informations d'un compte\n");
        printf("4. Supprimer un compte\n");
        printf("5. Afficher la liste des clients\n");
        printf("6. Gestion des transactions bancaires\n");
        printf("7. Calcul des int�r�ts pour les comptes d'�pargne\n");
        printf("8. Quitter\n");
        printf("Tapez Votre choix s'il vous pla�t : ");
        scanf("%d", &choix);

        switch (choix) {
    case 1:
        creerCompte(&listeComptes);
        break;
    case 2: {
        int numCompte;
        printf("Entrez le num�ro de compte � afficher : ");
        scanf("%d", &numCompte);
        afficherDetailsCompte(listeComptes, numCompte);
        break;
    }
    case 3: {
        int numCompte;
        printf("Entrez le num�ro de compte � mettre � jour : ");
        scanf("%d", &numCompte);
        mettreAJourInfosCompte(listeComptes, numCompte);
        break;
    }
    case 4: {
        int numCompte;
        printf("Entrez le num�ro de compte � supprimer : ");
        scanf("%d", &numCompte);
        supprimerCompte(&listeComptes, numCompte);
        break;
    }
    case 5:
        afficherListeClients(listeComptes);
        break;
    case 6: {
        int choixTransaction;
        printf("1. Effectuer un d�p�t\n");
        printf("2. Effectuer un retrait\n");
        printf("Tapez Votre choix s'il vous pla�t : ");
        scanf("%d", &choixTransaction);

        int numCompte;
        float montant;
        switch (choixTransaction) {
            case 1:
                printf("Entrez le num�ro de compte pour le d�p�t : ");
                scanf("%d", &numCompte);
                printf("Entrez le montant du d�p�t : ");
                scanf("%f", &montant);
                effectuerDepot(listeComptes, numCompte, montant);
                break;
            case 2:
                printf("Entrez le num�ro de compte pour le retrait : ");
                scanf("%d", &numCompte);
                printf("Entrez le montant du retrait : ");
                scanf("%f", &montant);
                effectuerRetrait(listeComptes, numCompte, montant);
                break;
            default:
                printf("Choix invalide.\n");
        }
        break;
    }
    case 7: {
        float tauxInteret;
        int numcompte;
        printf("Entrez le num�ro de compte pour le calcul d'inter�t: ");
        scanf("%d",&numcompte);
        printf("Entrez le taux d'int�r�t : ");
        scanf("%f", &tauxInteret);
        calculerInterets(listeComptes, tauxInteret,numcompte);
        break;
    }
    case 8:
        printf("Merci d'avoir utilis� Nidhal-E-Bank.\n");
        break;
    default:
        printf("Choix invalide.\n");
}
    }
     while (choix != 8);

    fichier = fopen("comptes.txt", "w");
    if (fichier != NULL) {
        CompteNode* temp = listeComptes;
        while (temp != NULL) {
            fprintf(fichier, "%d %s %.2f\n", temp->numero_compte, temp->nom_client, temp->solde);
            temp = temp->next;
        }
        fclose(fichier);
    } else {
        printf("Erreur lors de la sauvegarde des comptes.\n");
    }

    return 0;
}
